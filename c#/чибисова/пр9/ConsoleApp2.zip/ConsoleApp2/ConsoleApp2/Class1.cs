﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    class Student
    {
        private string _name;
        private int _age;

        public void PrintInfo()
        {
            Console.WriteLine($"Меня зовут {_name} мне {_age}");
        }

        // 3 
        public Student() { }
        public Student(string name, int age)
        {
            this.Name = name;
            this.Age = age;
        }
        public Student(int age)
        {
            _age = 19;
        }
        // 4 and 5  
        public string Name
        { 
            get { return _name; }
            set { if (value.Length < 2)
                {
                    Console.WriteLine("Имя меньше двух символов");
                    return;
                }
            _name = value;
            }
        }
        public int Age
        {
            get { return _age; }
            set { if (value > 16 || value < 60) {
                    Console.WriteLine("Возраст должен быть от 16 до 60 лет");
                    return;
                };
                _age = value;
            }
        }
        public static void PrintUniversity()
        {
            Console.WriteLine("Казанский Технический Колледж");
        }


    }

    class Book 
    {

        private string _title;
        private string _autor;
        private int _year;

        public Book(string title, string autor, int year) 
        {
            this._title = title;
            this._autor = autor;
            this._year = year;
        }


        public void Rename(string newTitle) 
        { 
            _title = newTitle;
        }

        public void PrintInfo()
        {
            Console.WriteLine($"Название: {_title}");
            Console.WriteLine($"Автор: {_autor}");
            Console.WriteLine($"Год издания: {_year}");
            Console.WriteLine("-------------------");
        }
    }

    class User 
    {
        private int _id { get; } = 0;
        private string _name
        {
            get { return _name; }
            set
            {
                if (value.Length < 2)
                {
                    Console.WriteLine("Имя меньше двух символов");
                    return;
                }
                _name = value;
            }
        }
        private int _age
        {
            get { return _age; }
            set
            {
                if (value > 0 || value < 120)
                {
                    Console.WriteLine("Возраст должен быть от 0 до 120 лет");
                    return;
                }
                ;
                _age = value;
            }
        }
        private string _email
        {
            get { return _email; }
            set
            {
                if (value.Contains("@"))
                {
                    _email = value;
                }
            }
        }
    }
}