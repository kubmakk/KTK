﻿using ConsoleApp2;

Student p1 = new("d", 12);
Student p2 = new("Bogsan", 13);

Console.WriteLine();
Book book = new Book("Война и мир", "Лев Толстой", 1869);
book.PrintInfo();
book.Rename("Роблокс истории");
book.PrintInfo();
